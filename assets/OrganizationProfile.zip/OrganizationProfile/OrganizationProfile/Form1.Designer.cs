﻿namespace OrganizationProfile
{
    partial class frmRegistration
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            txtStudentNo = new TextBox();
            txtLastName = new TextBox();
            txtAge = new TextBox();
            txtFirstName = new TextBox();
            label7 = new Label();
            datePickerBirthday = new DateTimePicker();
            label8 = new Label();
            label9 = new Label();
            txtContactNo = new TextBox();
            cbPrograms = new ComboBox();
            cbGender = new ComboBox();
            label10 = new Label();
            txtMiddleInitial = new TextBox();
            btnRegister = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(12, 9);
            label1.Name = "label1";
            label1.Size = new Size(184, 41);
            label1.TabIndex = 0;
            label1.Text = "Registration";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 9F);
            label2.Location = new Point(12, 73);
            label2.Name = "label2";
            label2.Size = new Size(87, 20);
            label2.TabIndex = 1;
            label2.Text = "Student No.";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 9F);
            label3.Location = new Point(20, 116);
            label3.Name = "label3";
            label3.Size = new Size(79, 20);
            label3.TabIndex = 2;
            label3.Text = "Last Name";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 9F);
            label4.Location = new Point(63, 166);
            label4.Name = "label4";
            label4.Size = new Size(36, 20);
            label4.TabIndex = 3;
            label4.Text = "Age";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 9F);
            label5.Location = new Point(261, 116);
            label5.Name = "label5";
            label5.Size = new Size(80, 20);
            label5.TabIndex = 4;
            label5.Text = "First Name";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 9F);
            label6.Location = new Point(275, 73);
            label6.Name = "label6";
            label6.Size = new Size(66, 20);
            label6.TabIndex = 5;
            label6.Text = "Program";
            // 
            // txtStudentNo
            // 
            txtStudentNo.Font = new Font("Segoe UI", 9F);
            txtStudentNo.Location = new Point(105, 70);
            txtStudentNo.Name = "txtStudentNo";
            txtStudentNo.Size = new Size(125, 27);
            txtStudentNo.TabIndex = 6;
            // 
            // txtLastName
            // 
            txtLastName.Font = new Font("Segoe UI", 9F);
            txtLastName.Location = new Point(105, 113);
            txtLastName.Name = "txtLastName";
            txtLastName.Size = new Size(125, 27);
            txtLastName.TabIndex = 7;
            // 
            // txtAge
            // 
            txtAge.Font = new Font("Segoe UI", 9F);
            txtAge.Location = new Point(105, 163);
            txtAge.Name = "txtAge";
            txtAge.Size = new Size(125, 27);
            txtAge.TabIndex = 8;
            // 
            // txtFirstName
            // 
            txtFirstName.Font = new Font("Segoe UI", 9F);
            txtFirstName.Location = new Point(347, 113);
            txtFirstName.Name = "txtFirstName";
            txtFirstName.Size = new Size(125, 27);
            txtFirstName.TabIndex = 9;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 9F);
            label7.Location = new Point(33, 219);
            label7.Name = "label7";
            label7.Size = new Size(64, 20);
            label7.TabIndex = 10;
            label7.Text = "Birthday";
            // 
            // datePickerBirthday
            // 
            datePickerBirthday.Font = new Font("Segoe UI", 9F);
            datePickerBirthday.Location = new Point(103, 214);
            datePickerBirthday.Name = "datePickerBirthday";
            datePickerBirthday.Size = new Size(250, 27);
            datePickerBirthday.TabIndex = 11;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 9F);
            label8.Location = new Point(291, 166);
            label8.Name = "label8";
            label8.Size = new Size(60, 20);
            label8.TabIndex = 12;
            label8.Text = "Gender:";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 9F);
            label9.Location = new Point(370, 215);
            label9.Name = "label9";
            label9.Size = new Size(87, 20);
            label9.TabIndex = 13;
            label9.Text = "Contact No.";
            // 
            // txtContactNo
            // 
            txtContactNo.Font = new Font("Segoe UI", 9F);
            txtContactNo.Location = new Point(463, 212);
            txtContactNo.Name = "txtContactNo";
            txtContactNo.Size = new Size(125, 27);
            txtContactNo.TabIndex = 14;
            // 
            // cbPrograms
            // 
            cbPrograms.Font = new Font("Segoe UI", 9F);
            cbPrograms.FormattingEnabled = true;
            cbPrograms.Location = new Point(347, 70);
            cbPrograms.Name = "cbPrograms";
            cbPrograms.Size = new Size(308, 28);
            cbPrograms.TabIndex = 15;
            // 
            // cbGender
            // 
            cbGender.Font = new Font("Segoe UI", 9F);
            cbGender.FormattingEnabled = true;
            cbGender.Location = new Point(357, 163);
            cbGender.Name = "cbGender";
            cbGender.Size = new Size(151, 28);
            cbGender.TabIndex = 16;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Segoe UI", 9F);
            label10.Location = new Point(492, 116);
            label10.Name = "label10";
            label10.Size = new Size(32, 20);
            label10.TabIndex = 17;
            label10.Text = "M.I.";
            // 
            // txtMiddleInitial
            // 
            txtMiddleInitial.Font = new Font("Segoe UI", 9F);
            txtMiddleInitial.Location = new Point(530, 113);
            txtMiddleInitial.Name = "txtMiddleInitial";
            txtMiddleInitial.Size = new Size(125, 27);
            txtMiddleInitial.TabIndex = 18;
            // 
            // btnRegister
            // 
            btnRegister.Font = new Font("Segoe UI", 9F);
            btnRegister.Location = new Point(261, 274);
            btnRegister.Name = "btnRegister";
            btnRegister.Size = new Size(143, 38);
            btnRegister.TabIndex = 19;
            btnRegister.Text = "Register";
            btnRegister.UseVisualStyleBackColor = true;
            btnRegister.Click += btnRegister_Click;
            // 
            // frmRegistration
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(668, 339);
            Controls.Add(btnRegister);
            Controls.Add(txtMiddleInitial);
            Controls.Add(label10);
            Controls.Add(cbGender);
            Controls.Add(cbPrograms);
            Controls.Add(txtContactNo);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(datePickerBirthday);
            Controls.Add(label7);
            Controls.Add(txtFirstName);
            Controls.Add(txtAge);
            Controls.Add(txtLastName);
            Controls.Add(txtStudentNo);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "frmRegistration";
            Text = "Form1";
            Load += frmRegistration_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private TextBox txtStudentNo;
        private TextBox txtLastName;
        private TextBox txtAge;
        private TextBox txtFirstName;
        private Label label7;
        private DateTimePicker datePickerBirthday;
        private Label label8;
        private Label label9;
        private TextBox txtContactNo;
        private ComboBox cbPrograms;
        private ComboBox cbGender;
        private Label label10;
        private TextBox txtMiddleInitial;
        private Button btnRegister;
    }
}
