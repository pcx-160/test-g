using System.Text.RegularExpressions;

namespace OrganizationProfile
{
    public partial class frmRegistration : Form
    {
        private string _FullName;
        private int _Age;
        private long _ContactNo;
        private long _StudentNo;
        public frmRegistration()
        {
            InitializeComponent();
        }

        private void frmRegistration_Load(object sender, EventArgs e)
        {
            string[] ListOfProgram = new string[] {
                "BS Information Technology",
                "BS Computer Science",
                "BS Information Systems",
                "BS in Accountancy",
                "BS in Hospitality Management",
                "BS in Tourism Management"
            };

            for (int i = 0; i < ListOfProgram.Length; i++)
            {
                cbPrograms.Items.Add(ListOfProgram[i]);
            }

            cbGender.Items.Add("Male");
            cbGender.Items.Add("Female");
        }

        private string FullName(string lastName, string firstName, string middleInitial)
        {
            if (!string.IsNullOrEmpty(lastName) && !string.IsNullOrEmpty(firstName))
            {
                return $"{lastName}, {firstName} {middleInitial}";
            }
            else
            {
                throw new ArgumentNullException("Name fields cannot be empty.");
            }
        }

        private int StudentNumber(string studentNo)
        {
            if (Regex.IsMatch(studentNo, @"^\d+$"))
            {
                return int.Parse(studentNo);
            }
            else
            {
                throw new FormatException("Invalid student number.");
            }
        }

        private long ContactNo(string contact)
        {
            if (Regex.IsMatch(contact, @"^\d+$"))
            {
                return long.Parse(contact);
            }
            else
            {
                throw new FormatException("Invalid contact number.");
            }
        }

        private int Age(string ageText)
        {
            if (int.TryParse(ageText, out int result))
            {
                if (result > 0 && result < 120)
                    return result;
                else
                    throw new OverflowException("Age is not in valid range.");
            }
            else
            {
                throw new FormatException("Invalid age.");
            }
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            try
            {
                StudentInformationClass.SetFullName = FullName(txtLastName.Text, txtFirstName.Text, txtMiddleInitial.Text);
                StudentInformationClass.SetStudentNo = StudentNumber(txtStudentNo.Text);
                StudentInformationClass.SetProgram = cbPrograms.Text;
                StudentInformationClass.SetGender = cbGender.Text;
                StudentInformationClass.SetContactNo = ContactNo(txtContactNo.Text);
                StudentInformationClass.SetAge = Age(txtAge.Text);
                StudentInformationClass.SetBirthday = datePickerBirthday.Value.ToString("yyyy-MM-dd");

                frmConfirmation frm = new frmConfirmation();
                frm.ShowDialog();
            }

            catch (FormatException ex)
            {
                MessageBox.Show($"Format Error: {ex.Message}");
            }
            catch (ArgumentNullException ex)
            {
                MessageBox.Show($"Missing Data: {ex.Message}");
            }
            catch (OverflowException ex)
            {
                MessageBox.Show($"Overflow Error: {ex.Message}");
            }
            catch (IndexOutOfRangeException ex)
            {
                MessageBox.Show($"Index Error: {ex.Message}");
            }
            finally
            {
                Console.WriteLine("Validation Attempt Finished.");
            }
        }
    }
}
